import { createServer } from 'node:http'
import type { IncomingMessage, ServerResponse } from 'node:http'
import { existsSync, readFileSync, statSync } from 'node:fs'
import { extname, join, normalize, sep } from 'node:path'
import { gzipSync } from 'node:zlib'
import { initSql } from '../db/init.js'
import { getPool } from '../db/index.js'
import { authConfigured, checkPassword, clearSessionCookie, createSessionCookie, isAdminRequest, tooManyAttempts } from './auth.js'
import { sameOrigin } from './http.js'
import content from './api/content.js'
import skinPrice from './api/skin-price.js'
import submissions from './api/submissions.js'
import videos from './api/videos.js'

// Pasta com o site já compilado (fica ao lado deste ficheiro, em «client»).
const clientDir = join(__dirname, 'client')

const mimeTypes: Record<string, string> = {
  '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8', '.svg': 'image/svg+xml', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
  '.webp': 'image/webp', '.ico': 'image/x-icon', '.woff2': 'font/woff2', '.otf': 'font/otf', '.txt': 'text/plain; charset=utf-8', '.xml': 'application/xml',
}
const compressible = new Set(['.html', '.js', '.css', '.json', '.svg', '.txt', '.xml'])
const gzipCache = new Map<string, { mtime: number; data: Buffer }>()

function securityHeaders(): Record<string, string> {
  return { 'X-Content-Type-Options': 'nosniff', 'Referrer-Policy': 'strict-origin-when-cross-origin', 'X-Frame-Options': 'SAMEORIGIN' }
}

function clientIp(req: IncomingMessage) {
  const forwarded = req.headers['x-forwarded-for']
  const first = (Array.isArray(forwarded) ? forwarded[0] : forwarded)?.split(',')[0]?.trim()
  return first || req.socket.remoteAddress || 'unknown'
}

async function readBody(req: IncomingMessage, limit: number) {
  const chunks: Buffer[] = []
  let size = 0
  for await (const chunk of req) {
    size += (chunk as Buffer).length
    if (size > limit) throw new Error('too-large')
    chunks.push(chunk as Buffer)
  }
  return Buffer.concat(chunks)
}

async function toRequest(req: IncomingMessage) {
  const host = String(req.headers['x-forwarded-host'] || req.headers.host || 'localhost')
  const hasBody = req.method !== 'GET' && req.method !== 'HEAD'
  const body = hasBody ? await readBody(req, 20000) : undefined
  const headers = new Headers()
  for (const [name, value] of Object.entries(req.headers)) if (value !== undefined) headers.set(name, Array.isArray(value) ? value.join(', ') : value)
  return new Request(`https://${host}${req.url || '/'}`, { method: req.method, headers, body: body && body.length ? new Uint8Array(body) : undefined })
}

async function sendResponse(res: ServerResponse, response: Response) {
  const cookies = response.headers.getSetCookie?.() ?? []
  const headers: Record<string, string | string[]> = { ...securityHeaders() }
  response.headers.forEach((value, name) => { if (name !== 'set-cookie') headers[name] = value })
  if (cookies.length) headers['Set-Cookie'] = cookies
  res.writeHead(response.status, headers)
  res.end(Buffer.from(await response.arrayBuffer()))
}

const json = (data: unknown, status = 200, extra: Record<string, string> = {}) => Response.json(data, { status, headers: { 'Cache-Control': 'no-store', ...extra } })

async function handleAdmin(request: Request, path: string, req: IncomingMessage) {
  if (path === '/api/admin/session' && request.method === 'GET') return json({ admin: isAdminRequest(request) })
  if (path === '/api/admin/logout' && request.method === 'POST') {
    if (!sameOrigin(request)) return json({ message: 'Pedido não autorizado.' }, 403)
    return json({ ok: true }, 200, { 'Set-Cookie': clearSessionCookie() })
  }
  if (path === '/api/admin/login' && request.method === 'POST') {
    if (!sameOrigin(request)) return json({ message: 'Pedido não autorizado.' }, 403)
    if (!authConfigured()) return json({ message: 'O acesso de administrador ainda não está configurado no servidor.' }, 503)
    if (tooManyAttempts(clientIp(req))) return json({ message: 'Demasiadas tentativas. Tenta novamente dentro de 15 minutos.' }, 429)
    const body = await request.json().catch(() => null) as { password?: unknown } | null
    if (!body || typeof body.password !== 'string' || !checkPassword(body.password)) return json({ message: 'Palavra-passe inválida.' }, 401)
    return json({ ok: true }, 200, { 'Set-Cookie': createSessionCookie(true) })
  }
  return json({ message: 'Não encontrado.' }, 404)
}

async function handleApi(req: IncomingMessage, res: ServerResponse, path: string) {
  try {
    const request = await toRequest(req)
    let response: Response
    if (path === '/api/submissions') response = await submissions(request)
    else if (path === '/api/content') response = await content(request, isAdminRequest(request))
    else if (path === '/api/skin-price') response = await skinPrice(request)
    else if (path === '/api/videos') response = await videos(request)
    else if (path.startsWith('/api/admin/')) response = await handleAdmin(request, path, req)
    else response = json({ message: 'Não encontrado.' }, 404)
    await sendResponse(res, response)
  } catch (error) {
    const tooLarge = error instanceof Error && error.message === 'too-large'
    await sendResponse(res, json({ message: tooLarge ? 'O pedido é demasiado longo.' : 'Erro no servidor.' }, tooLarge ? 413 : 500))
  }
}

function serveFile(req: IncomingMessage, res: ServerResponse, filePath: string, urlPath: string, status = 200) {
  const extension = extname(filePath).toLowerCase()
  const stats = statSync(filePath)
  let data = readFileSync(filePath)
  const headers: Record<string, string | number> = { ...securityHeaders(), 'Content-Type': mimeTypes[extension] || 'application/octet-stream' }
  if (extension === '.html') headers['Cache-Control'] = 'no-cache'
  else if (urlPath.startsWith('/assets/')) headers['Cache-Control'] = 'public, max-age=31536000, immutable'
  else headers['Cache-Control'] = 'public, max-age=86400'
  if (compressible.has(extension) && String(req.headers['accept-encoding'] || '').includes('gzip') && data.length > 1024) {
    const cached = gzipCache.get(filePath)
    const mtime = stats.mtimeMs
    if (cached && cached.mtime === mtime) data = cached.data
    else { data = gzipSync(data); gzipCache.set(filePath, { mtime, data }) }
    headers['Content-Encoding'] = 'gzip'
    headers.Vary = 'Accept-Encoding'
  }
  headers['Content-Length'] = data.length
  res.writeHead(status, headers)
  res.end(req.method === 'HEAD' ? undefined : data)
}

function handleStatic(req: IncomingMessage, res: ServerResponse, path: string) {
  if (req.method !== 'GET' && req.method !== 'HEAD') { res.writeHead(405, { Allow: 'GET, HEAD' }); res.end(); return }
  let decoded = '/'
  try { decoded = decodeURIComponent(path) } catch { res.writeHead(400); res.end(); return }
  const safe = normalize(decoded).replace(/^(\.\.[/\\])+/, '')
  const target = join(clientDir, safe)
  if (!target.startsWith(clientDir + sep) && target !== clientDir) { res.writeHead(403); res.end(); return }
  if (existsSync(target) && statSync(target).isFile()) return serveFile(req, res, target, decoded)
  // Ficheiros com extensão que não existem: 404. Qualquer outra rota (ex.: /admin) abre o site.
  if (extname(decoded)) { res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Não encontrado'); return }
  for (const shell of ['index.html', '_shell.html']) {
    const shellPath = join(clientDir, shell)
    if (existsSync(shellPath)) return serveFile(req, res, shellPath, '/index.html')
  }
  res.writeHead(500, { 'Content-Type': 'text/plain; charset=utf-8' }); res.end('Site não encontrado: falta a pasta «client».')
}

async function prepareDatabase() {
  if (!process.env.DATABASE_URL) { console.error('[mig] DATABASE_URL não definida: formulários e conteúdo editável não vão funcionar.'); return }
  try { await getPool().query(initSql); console.log('[mig] Base de dados pronta.') }
  catch (error) { console.error('[mig] Não foi possível preparar a base de dados:', error instanceof Error ? error.message : 'erro desconhecido') }
}

const server = createServer((req, res) => {
  const path = new URL(req.url || '/', 'http://localhost').pathname
  if (path.startsWith('/api/')) void handleApi(req, res, path)
  else handleStatic(req, res, path)
})

void prepareDatabase()
server.listen(process.env.PORT || 3000, () => console.log('[mig] Servidor iniciado.'))
