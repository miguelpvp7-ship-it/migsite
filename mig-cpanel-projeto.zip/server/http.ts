// Utilitários HTTP partilhados pelo servidor.

// Atrás do proxy do cPanel o endereço pode chegar como http; por isso comparamos só o domínio.
export function sameOrigin(request: Request) {
  const origin = request.headers.get('origin')
  if (!origin) return false
  try {
    const host = request.headers.get('x-forwarded-host') || request.headers.get('host') || new URL(request.url).host
    return new URL(origin).host === host
  } catch {
    return false
  }
}
