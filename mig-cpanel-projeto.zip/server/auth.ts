import { createHmac, timingSafeEqual } from 'node:crypto'

// Login simples do administrador: palavra-passe guardada em variável de ambiente (ADMIN_PASSWORD).
// A sessão é um cookie assinado com SESSION_SECRET, válido durante 12 horas.
const cookieName = 'mig_admin'
const sessionMs = 12 * 60 * 60 * 1000

function sign(payload: string) {
  return createHmac('sha256', process.env.SESSION_SECRET || '').update(payload).digest('hex')
}

function safeEqual(first: string, second: string) {
  const a = Buffer.from(first)
  const b = Buffer.from(second)
  return a.length === b.length && timingSafeEqual(a, b)
}

export function authConfigured() {
  return Boolean(process.env.ADMIN_PASSWORD && process.env.SESSION_SECRET && process.env.SESSION_SECRET.length >= 24)
}

export function checkPassword(password: string) {
  const expected = process.env.ADMIN_PASSWORD || ''
  return authConfigured() && safeEqual(sign(password), sign(expected))
}

export function createSessionCookie(secure: boolean) {
  const expires = String(Date.now() + sessionMs)
  const value = `${expires}.${sign(expires)}`
  return `${cookieName}=${value}; Path=/; HttpOnly; SameSite=Strict; Max-Age=${sessionMs / 1000}${secure ? '; Secure' : ''}`
}

export function clearSessionCookie() {
  return `${cookieName}=; Path=/; HttpOnly; SameSite=Strict; Max-Age=0`
}

export function isAdminRequest(request: Request) {
  if (!authConfigured()) return false
  const cookie = (request.headers.get('cookie') || '').split(';').map((part) => part.trim()).find((part) => part.startsWith(`${cookieName}=`))
  if (!cookie) return false
  const [expires, signature] = cookie.slice(cookieName.length + 1).split('.')
  if (!expires || !signature || !/^\d+$/.test(expires) || Number(expires) < Date.now()) return false
  return safeEqual(signature, sign(expires))
}

// Limite simples de tentativas de login por IP (em memória).
const attempts = new Map<string, { count: number; resetAt: number }>()
export function tooManyAttempts(ip: string) {
  const now = Date.now()
  const entry = attempts.get(ip)
  if (!entry || entry.resetAt < now) { attempts.set(ip, { count: 1, resetAt: now + 15 * 60 * 1000 }); return false }
  entry.count += 1
  return entry.count > 8
}
