import { createCipheriv, createDecipheriv, randomBytes } from 'node:crypto'
import { eq } from 'drizzle-orm'
import { getDatabase } from '../../db/index.js'
import { integrations } from '../../db/schema.js'

type TikTokVideo = { id: string; title?: string; video_description?: string; cover_image_url: string; view_count: number; create_time: number; share_url: string }

function encrypt(value: string, key: Buffer) {
  const nonce = randomBytes(12)
  const cipher = createCipheriv('aes-256-gcm', key, nonce)
  const ciphertext = Buffer.concat([cipher.update(value, 'utf8'), cipher.final()])
  return [nonce, cipher.getAuthTag(), ciphertext].map((part) => part.toString('base64')).join('.')
}
function decrypt(value: string, key: Buffer) {
  const [nonce, tag, ciphertext] = value.split('.').map((part) => Buffer.from(part, 'base64'))
  if (!nonce || !tag || !ciphertext) throw new Error('Integração inválida')
  const decipher = createDecipheriv('aes-256-gcm', key, nonce)
  decipher.setAuthTag(tag)
  return Buffer.concat([decipher.update(ciphertext), decipher.final()]).toString('utf8')
}

async function getAccessToken() {
  const clientKey = process.env.TIKTOK_CLIENT_KEY
  const clientSecret = process.env.TIKTOK_CLIENT_SECRET
  const keyHex = process.env.TIKTOK_TOKEN_ENCRYPTION_KEY
  if (!clientKey || !clientSecret || !keyHex || !/^[a-fA-F0-9]{64}$/.test(keyHex)) return null
  const key = Buffer.from(keyHex, 'hex')
  const database = getDatabase()
  const [connection] = await database.select().from(integrations).where(eq(integrations.id, 'tiktok-mig')).limit(1)
  if (connection && connection.expiresAt.getTime() > Date.now() + 300000) return decrypt(connection.encryptedAccessToken, key)
  const refreshToken = connection ? decrypt(connection.encryptedRefreshToken, key) : process.env.TIKTOK_REFRESH_TOKEN
  if (!refreshToken) return null
  const response = await fetch('https://open.tiktokapis.com/v2/oauth/token/', { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams({ client_key: clientKey, client_secret: clientSecret, grant_type: 'refresh_token', refresh_token: refreshToken }), signal: AbortSignal.timeout(10000) })
  if (!response.ok) throw new Error('Autorização indisponível')
  const tokens = await response.json() as { access_token?: string; refresh_token?: string; expires_in?: number; error?: string; scope?: string }
  if (tokens.error || !tokens.access_token || !tokens.refresh_token || !tokens.expires_in || !tokens.scope?.split(',').includes('video.list')) throw new Error('É necessária autorização video.list')
  const values = { id: 'tiktok-mig', encryptedAccessToken: encrypt(tokens.access_token, key), encryptedRefreshToken: encrypt(tokens.refresh_token, key), expiresAt: new Date(Date.now() + tokens.expires_in * 1000), updatedAt: new Date() }
  await database.insert(integrations).values(values).onConflictDoUpdate({ target: integrations.id, set: values })
  return tokens.access_token
}

async function latestVideos(token: string) {
  const collected: TikTokVideo[] = []
  let cursor: number | undefined
  const fields = 'id,title,video_description,cover_image_url,share_url,view_count,create_time'
  for (let pageIndex = 0; pageIndex < 4; pageIndex += 1) {
    const response = await fetch(`https://open.tiktokapis.com/v2/video/list/?fields=${fields}`, { method: 'POST', headers: { Authorization: `Bearer ${token}`, 'Content-Type': 'application/json' }, body: JSON.stringify({ max_count: 20, cursor }), signal: AbortSignal.timeout(8000) })
    if (!response.ok) throw new Error('Vídeos indisponíveis')
    const payload = await response.json() as { data?: { videos?: TikTokVideo[]; cursor?: number; has_more?: boolean }; error?: { code?: string } }
    if (payload.error?.code && payload.error.code !== 'ok') throw new Error('Vídeos indisponíveis')
    for (const video of payload.data?.videos || []) {
      if (/^\d+$/.test(video.id) && Number.isFinite(video.view_count) && video.view_count >= 0 && Number.isFinite(video.create_time) && !collected.some((existing) => existing.id === video.id)) collected.push(video)
    }
    if (collected.length >= 20 || !payload.data?.has_more || !payload.data.cursor || payload.data.cursor === cursor) break
    cursor = payload.data.cursor
  }
  return collected.sort((first, second) => second.create_time - first.create_time).slice(0, 20)
}

export default async function videos(request: Request) {
  if (request.method !== 'GET') return Response.json({ videos: [] }, { status: 405, headers: { Allow: 'GET', 'Cache-Control': 'no-store' } })
  try {
    const token = await getAccessToken()
    if (!token) return Response.json({ videos: [], status: 'not_connected' }, { headers: { 'Cache-Control': 'no-store' } })
    const recent = await latestVideos(token)
    const ranked = recent.sort((first, second) => second.view_count - first.view_count || second.create_time - first.create_time).slice(0, 5).map((video) => ({ id: video.id, title: video.title || video.video_description || 'CS2 com o MIG', cover: video.cover_image_url, views: video.view_count, url: `https://www.tiktok.com/@mig.cs/video/${video.id}` }))
    return Response.json({ videos: ranked, recentCount: recent.length }, { headers: { 'Cache-Control': 'public, max-age=60' } })
  } catch {
    return Response.json({ videos: [], status: 'temporarily_unavailable' }, { status: 503, headers: { 'Cache-Control': 'no-store' } })
  }
}

