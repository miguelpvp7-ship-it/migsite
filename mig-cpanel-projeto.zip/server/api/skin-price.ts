import { z } from 'zod'
import { quoteSkin, wearValues } from '../../server/skin-pricing.js'

const query = z.object({ name: z.string().trim().min(3).max(120), wear: z.enum(wearValues) })

export default async function skinPrice(request: Request) {
  if (request.method !== 'GET') return Response.json({ message: 'Método não permitido.' }, { status: 405, headers: { Allow: 'GET' } })
  const url = new URL(request.url)
  const parsed = query.safeParse({ name: url.searchParams.get('name'), wear: url.searchParams.get('wear') })
  if (!parsed.success) return Response.json({ message: 'Indica o nome da skin e o estado.' }, { status: 400, headers: { 'Cache-Control': 'no-store' } })
  try {
    const quote = await quoteSkin(parsed.data.name, parsed.data.wear)
    if (!quote) return Response.json({ message: 'Não encontrámos preço Buff163 para esta skin neste estado. Confirma o nome (ex.: AK-47 | Redline).' }, { status: 404, headers: { 'Cache-Control': 'public, max-age=300' } })
    return Response.json(quote, { headers: { 'Cache-Control': 'public, max-age=300' } })
  } catch {
    return Response.json({ message: 'Não foi possível obter o preço neste momento. Tenta novamente dentro de momentos.' }, { status: 503, headers: { 'Cache-Control': 'no-store' } })
  }
}

