import { eq } from 'drizzle-orm'
import { z } from 'zod'
import { getDatabase } from '../../db/index.js'
import { siteContent } from '../../db/schema.js'

export const defaults = {
  heroTitle: 'CS2. SKINS. SEM FILTROS.',
  heroDescription: 'Sou o mig. Crio conteúdo, exploro inventários e partilho o melhor do Counter-Strike com a minha comunidade.',
  aboutTitle: 'FARTO DE JOGAR? FAZ DINHEIRO COM AS TUAS SKINS!',
  aboutDescription: 'Caso estejas aborrecido de jogar ou tenhas alguma urgência e necessites de vender as tuas skins, eu compro-as.',
  heroImage: '',
  aboutImage: '',
  showVideos: 'true',
  showAbout: 'true',
  showSocials: 'true',
}
const keys = z.enum(Object.keys(defaults) as [string, ...string[]])

export default async function content(request: Request, isAdmin: boolean) {
  if (request.method === 'GET') {
    const database = getDatabase()
    const rows = await database.select().from(siteContent)
    const storedContent = Object.fromEntries(rows.map((row) => [row.key, row.value]))
    if (storedContent.aboutTitle === 'Mais do que skins. Uma comunidade.') storedContent.aboutTitle = defaults.aboutTitle
    if (storedContent.aboutDescription === 'Sou o MIG e o CS2 é o nosso ponto de encontro. Por aqui há inventários para descobrir, skins para conversar e vídeos feitos contigo. Se também vives este jogo, estás em casa.') storedContent.aboutDescription = defaults.aboutDescription
    return Response.json({ ...defaults, ...storedContent }, { headers: { 'Cache-Control': 'no-store' } })
  }
  if (!isAdmin) return Response.json({ message: 'Acesso reservado ao administrador.' }, { status: 403 })
  if (request.method !== 'PUT') return Response.json({ message: 'Método não permitido.' }, { status: 405 })
  const database = getDatabase()
  const body = await request.json() as Record<string, unknown>
  const updates = Object.entries(body).filter(([key, value]) => keys.safeParse(key).success && typeof value === 'string' && value.length <= 5000)
  await Promise.all(updates.map(([key, value]) => database.insert(siteContent).values({ key, value: value as string }).onConflictDoUpdate({ target: siteContent.key, set: { value: value as string, updatedAt: new Date() } })))
  return Response.json({ ok: true })
}
