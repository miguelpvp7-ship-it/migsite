import { z } from 'zod'
import { sameOrigin } from '../http.js'
import { getDatabase } from '../../db/index.js'
import { inventoryRequests, partnershipRequests, skinOffers } from '../../db/schema.js'
import { quoteSkin, wearOptions, wearValues } from '../../server/skin-pricing.js'
import type { SkinOfferItem } from '../../server/skin-pricing.js'

function submissionSchema() {
  const steamUrl = z.string().trim().max(250).refine((value) => {
    try {
      const url = new URL(value)
      return url.protocol === 'https:' && url.hostname === 'steamcommunity.com' && !url.port && !url.username && !url.password && /^\/(?:id\/[^/]+|profiles\/\d{17})\/?$/.test(url.pathname)
    } catch { return false }
  }, 'Usa um link válido: https://steamcommunity.com/id/nome ou /profiles/ID.')
  const common = { name: z.string().trim().min(2).max(150), privacyConsent: z.literal('yes'), website: z.string().max(300).optional() }
  const inventory = z.object({ ...common, type: z.literal('inventory'), steamUrl, platform: z.enum(['tiktok', 'instagram']), socialHandle: z.string().trim().min(2).max(80).regex(/^@?[a-zA-Z0-9._]{2,60}$/, 'Indica apenas o teu username, com ou sem @.'), followsCreator: z.literal('yes') })
  const skins = z.object({ ...common, type: z.literal('skins'), steamUrl, socialHandle: z.string().trim().min(2).max(80), items: z.string().max(6000).transform((value, context) => { try { return JSON.parse(value) as unknown } catch { context.addIssue({ code: 'custom', message: 'Adiciona pelo menos uma skin.' }); return z.NEVER } }).pipe(z.array(z.object({ name: z.string().trim().min(3).max(120), wear: z.enum(wearValues) }), { error: 'Adiciona pelo menos uma skin.' }).min(1, 'Adiciona pelo menos uma skin.').max(20, 'Podes propor até 20 skins de cada vez.')), notes: z.string().trim().max(3000), payment: z.enum(['transfer', 'crypto']) })
  const partnership = z.object({ ...common, type: z.literal('partnership'), email: z.email().max(254), brandUrl: z.union([z.url({ protocol: /^https?$/ }).max(300), z.literal('')]), message: z.string().trim().min(10).max(5000) })
  return z.discriminatedUnion('type', [inventory, skins, partnership])
}

export default async function submit(request: Request) {
  const headers = { 'Cache-Control': 'no-store' }
  if (request.method !== 'POST') return Response.json({ message: 'Método não permitido.' }, { status: 405, headers: { ...headers, Allow: 'POST' } })
  if (!sameOrigin(request)) return Response.json({ message: 'Pedido não autorizado.' }, { status: 403, headers })
  if (!request.headers.get('content-type')?.startsWith('application/json')) return Response.json({ message: 'Formato inválido.' }, { status: 415, headers })
  try {
    if (Number(request.headers.get('content-length') || 0) > 16000) return Response.json({ message: 'O pedido é demasiado longo.' }, { status: 413, headers })
    const rawBody = await request.text()
    if (rawBody.length > 16000) return Response.json({ message: 'O pedido é demasiado longo.' }, { status: 413, headers })
    let body: unknown
    try { body = JSON.parse(rawBody) } catch { return Response.json({ message: 'Pedido inválido.' }, { status: 400, headers }) }
    if (typeof body === 'object' && body !== null && 'website' in body && body.website) return Response.json({ message: 'Pedido recebido.' }, { status: 201, headers })
    const parsed = submissionSchema().safeParse(body)
    if (!parsed.success) {
      const issue = parsed.error.issues[0]
      const labels: Record<string, string> = { name: 'nome pessoal', steamUrl: 'perfil Steam', platform: 'rede social', socialHandle: 'username', followsCreator: 'confirmação de que segues o MIG', privacyConsent: 'autorização de privacidade', items: 'skins a vender', notes: 'observações', payment: 'meio de pagamento', email: 'email', brandUrl: 'site ou rede social', message: 'proposta' }
      const field = labels[String(issue?.path[0])] || 'dados do pedido'
      const message = issue?.code === 'custom' ? issue.message : `Confirma o campo «${field}». Deve estar preenchido e respeitar o formato indicado.`
      return Response.json({ message }, { status: 400, headers })
    }
    const data = parsed.data
    const database = getDatabase()
    if (data.type === 'inventory') await database.insert(inventoryRequests).values({ name: data.name, steamUrl: data.steamUrl, platform: data.platform, socialHandle: data.socialHandle, followsCreator: true, privacyConsent: true })
    else if (data.type === 'skins') {
      const items: SkinOfferItem[] = await Promise.all(data.items.map(async (item) => {
        const quote = await quoteSkin(item.name, item.wear).catch(() => null)
        return { name: quote?.name ?? item.name, wear: item.wear, buffUsd: quote?.buffUsd ?? null, buffEur: quote?.buffEur ?? null, offerEur: quote?.offerEur ?? null, sourceUrl: quote?.sourceUrl ?? null }
      }))
      const wearLabel = (wear: string) => wearOptions.find((option) => option.value === wear)?.label ?? wear
      const skins = items.map((item) => `${item.name} (${wearLabel(item.wear)})${item.offerEur === null ? ' — sem preço Buff163' : ` — oferta ${item.offerEur.toFixed(2)} €`}`).join('\n')
      const wears = [...new Set(items.map((item) => item.wear))]
      await database.insert(skinOffers).values({ name: data.name, steamUrl: data.steamUrl, socialHandle: data.socialHandle, skins, wear: wears.length === 1 ? wears[0] : 'multiple', notes: data.notes, payment: data.payment, items, privacyConsent: true })
    }
    else await database.insert(partnershipRequests).values({ name: data.name, email: data.email, brandUrl: data.brandUrl, message: data.message, privacyConsent: true })
    return Response.json({ message: 'Pedido recebido.' }, { status: 201, headers })
  } catch {
    return Response.json({ message: 'Não foi possível guardar o pedido. Os teus dados continuam no formulário; tenta novamente dentro de momentos.' }, { status: 503, headers })
  }
}

