export const wearOptions = [
  { value: 'factory-new', label: 'Factory New' },
  { value: 'minimal-wear', label: 'Minimal Wear' },
  { value: 'field-tested', label: 'Field-Tested' },
  { value: 'well-worn', label: 'Well-Worn' },
  { value: 'battle-scarred', label: 'Battle-Scarred' },
] as const
export type Wear = (typeof wearOptions)[number]['value']
export const wearValues = wearOptions.map((option) => option.value) as [Wear, ...Wear[]]

export const offerRate = 0.85

export type SkinQuote = { name: string; wear: Wear; image: string | null; buffUsd: number; buffEur: number; offerEur: number; sourceUrl: string }
export type SkinOfferItem = { name: string; wear: Wear; buffUsd: number | null; buffEur: number | null; offerEur: number | null; sourceUrl: string | null }

const userAgent = 'Mozilla/5.0 (compatible; MIG-CS2/1.0; +' + (process.env.SITE_URL || 'https://migcs.site') + ')'

export function skinSlug(name: string, wear: Wear) {
  const normalized = name.toLowerCase().replace(/[★™]/g, ' ').replace(/\(([^)]*)\)\s*$/, ' ').trim()
  const variant = /^stat\s*-?\s*trak\b/.test(normalized) ? 'stattrak-' : /^souvenir\b/.test(normalized) ? 'souvenir-' : ''
  const base = normalized.replace(/^stat\s*-?\s*trak\b|^souvenir\b/, '').normalize('NFKD').replace(/[̀-ͯ]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '')
  return base ? `${base}/${variant}${wear}` : null
}

function parsePrice(value: string) {
  const price = Number(value.replace(/[^0-9.]/g, ''))
  return Number.isFinite(price) && price > 0 ? price : null
}

let cachedRate: { value: number; expiresAt: number } | null = null
async function usdToEurRate() {
  if (cachedRate && cachedRate.expiresAt > Date.now()) return cachedRate.value
  const response = await fetch('https://api.frankfurter.dev/v1/latest?base=USD&symbols=EUR', { headers: { Accept: 'application/json' } })
  if (!response.ok) throw new Error('rate unavailable')
  const data = await response.json() as { rates?: { EUR?: number } }
  const rate = data.rates?.EUR
  if (typeof rate !== 'number' || rate <= 0) throw new Error('rate unavailable')
  cachedRate = { value: rate, expiresAt: Date.now() + 30 * 60 * 1000 }
  return rate
}

/** Looks up the Buff163 listing on csgoskins.gg. Returns null when the item or the Buff163 price does not exist. */
export async function quoteSkin(name: string, wear: Wear): Promise<SkinQuote | null> {
  const slug = skinSlug(name, wear)
  if (!slug) return null
  const sourceUrl = `https://csgoskins.gg/items/${slug}`
  const [page, rate] = await Promise.all([fetch(sourceUrl, { headers: { 'User-Agent': userAgent, Accept: 'text/html' }, redirect: 'follow' }), usdToEurRate()])
  if (page.status === 404) return null
  if (!page.ok) throw new Error('price source unavailable')
  const html = await page.text()
  const buffIndex = html.indexOf('markets/buff163"')
  if (buffIndex === -1) return null
  const priceMatch = html.slice(buffIndex, buffIndex + 4000).match(/from\s*<\/div>\s*<div[^>]*>\s*([^<]+?)\s*<\/div>/)
  const buffUsd = priceMatch ? parsePrice(priceMatch[1]) : null
  if (!buffUsd) return null
  const title = html.match(/<h1[^>]*>([\s\S]*?)<\/h1>/)?.[1].replace(/<[^>]+>/g, '').replace(/&amp;/g, '&').replace(/&#039;|&apos;/g, "'").replace(/\s+/g, ' ').trim()
  const image = html.match(/https:\/\/cdn\.csgoskins\.gg\/public\/uih\/products\/[^"'\s]+\.png/)?.[0] ?? null
  const buffEur = Math.round(buffUsd * rate * 100) / 100
  const variant = slug.split('/')[1].startsWith('stattrak-') ? 'StatTrak™ ' : slug.split('/')[1].startsWith('souvenir-') ? 'Souvenir ' : ''
  return { name: title ? `${variant}${title}` : name, wear, image, buffUsd, buffEur, offerEur: Math.round(buffEur * offerRate * 100) / 100, sourceUrl }
}
