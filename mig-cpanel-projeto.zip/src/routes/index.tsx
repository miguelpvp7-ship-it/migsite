import { createFileRoute } from '@tanstack/react-router'
import MigSite from '@/components/MigSite'

export const Route = createFileRoute('/')({ component: MigSite })
