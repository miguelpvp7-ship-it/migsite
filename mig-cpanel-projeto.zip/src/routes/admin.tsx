import { useEffect, useState } from 'react'
import { createFileRoute } from '@tanstack/react-router'

type Content = Record<string, string>
const fields = [['heroTitle', 'Título principal'], ['heroDescription', 'Descrição principal'], ['aboutTitle', 'Título sobre o mig'], ['aboutDescription', 'Texto sobre o mig'], ['heroImage', 'URL da imagem principal'], ['aboutImage', 'URL da imagem sobre o mig'], ['showVideos', 'Mostrar vídeos (true/false)'], ['showAbout', 'Mostrar secção sobre o mig (true/false)'], ['showSocials', 'Mostrar redes sociais (true/false)']]

export const Route = createFileRoute('/admin')({ component: Admin })
function Admin() {
  const [loggedIn, setLoggedIn] = useState(false)
  const [content, setContent] = useState<Content>({})
  const [password, setPassword] = useState('')
  const [message, setMessage] = useState('')
  useEffect(() => { fetch('/api/admin/session').then((response) => response.json()).then((result: { admin?: boolean }) => setLoggedIn(result.admin === true)).catch(() => undefined); fetch('/api/content').then((response) => response.json()).then(setContent) }, [])
  async function signIn(event: React.FormEvent) { event.preventDefault(); try { const response = await fetch('/api/admin/login', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ password }) }); const result = await response.json() as { message?: string }; if (!response.ok) throw new Error(result.message || 'Não foi possível iniciar sessão.'); setLoggedIn(true); setPassword(''); setMessage('Sessão iniciada.') } catch (error) { setMessage(error instanceof Error ? error.message : 'Não foi possível iniciar sessão.') } }
  async function signOut() { await fetch('/api/admin/logout', { method: 'POST' }).catch(() => undefined); setLoggedIn(false) }
  async function save(event: React.FormEvent) { event.preventDefault(); const response = await fetch('/api/content', { method: 'PUT', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(content) }); setMessage(response.ok ? 'Alterações guardadas.' : 'Sem permissões de administrador.') }
  if (!loggedIn) return <main className="admin-page"><a href="/">← Voltar ao site</a><div className="admin-card"><span className="eyebrow">ÁREA PRIVADA</span><h1>Administração<span>.</span></h1><p>Entra para gerir textos, imagens e secções do site.</p><form onSubmit={signIn}><label className="field"><span>Palavra-passe</span><input type="password" value={password} onChange={(event) => setPassword(event.target.value)} required /></label><button className="button primary" type="submit">Entrar</button></form>{message ? <p className="form-error">{message}</p> : null}</div></main>
  return <main className="admin-page"><div className="admin-header"><div><a href="/">← Voltar ao site</a><h1>Editar o site<span>.</span></h1></div><button className="button secondary" onClick={signOut}>Terminar sessão</button></div><form className="admin-card admin-form" onSubmit={save}><p>As alterações ficam disponíveis no site público assim que forem guardadas.</p>{fields.map(([key, label]) => <label className="field" key={key}><span>{label}</span>{key.includes('Description') ? <textarea rows={4} value={content[key] || ''} onChange={(event) => setContent({ ...content, [key]: event.target.value })} /> : <input value={content[key] || ''} onChange={(event) => setContent({ ...content, [key]: event.target.value })} />}</label>)}<button className="button primary" type="submit">Guardar alterações</button>{message ? <p role="status">{message}</p> : null}</form></main>
}
