import { useEffect, useRef, useState } from 'react'
import type { FormEvent, ReactNode } from 'react'
import { ArrowRight, ArrowUpRight, Check, Crosshair, LoaderCircle, Plus, Trash2, Instagram, Menu, ShieldCheck, X, Youtube } from 'lucide-react'

type Page = 'home' | 'inventario' | 'skins' | 'parcerias'
type SiteContent = { heroTitle?: string; heroDescription?: string; aboutTitle?: string; aboutDescription?: string; heroImage?: string; aboutImage?: string; showVideos?: string; showAbout?: string; showSocials?: string }
function useSiteContent() {
  const [content, setContent] = useState<SiteContent>({})
  useEffect(() => { fetch('/api/content').then((response) => response.ok ? response.json() : {}).then(setContent).catch(() => undefined) }, [])
  return content
}
const navigation: { id: Page; label: string }[] = [{ id: 'home', label: 'HUB' }, { id: 'inventario', label: 'ANÁLISE INVENTÁRIO' }, { id: 'skins', label: 'VENDER SKIN' }, { id: 'parcerias', label: 'PARCERIAS' }]

function TikTokIcon() {
  return <svg viewBox="0 0 24 24" fill="currentColor" aria-hidden="true"><path d="M15.6 3c.4 2.1 1.6 3.6 3.9 3.8v3.1a8 8 0 0 1-3.9-1.2v6.4a6 6 0 1 1-5.2-6v3.2a2.8 2.8 0 1 0 2 2.8V3h3.2Z" /></svg>
}
function SteamIcon() {
  return <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" aria-hidden="true"><circle cx="15.5" cy="7.5" r="4.5" /><circle cx="15.5" cy="7.5" r="2.3" /><circle cx="7.5" cy="16.5" r="3.7" /><path d="m1.5 13.7 5.3 2.8m3.4-2.2 3-3.1m-3.7 8 8.2-7.5" /></svg>
}
function ExternalLink({ href, children, className = '' }: { href: string; children: ReactNode; className?: string }) {
  return <a href={href} target="_blank" rel="noopener noreferrer" className={className}>{children}</a>
}
const socials = [
  { name: 'TikTok', handle: '@mig.cs', url: 'https://www.tiktok.com/@mig.cs', icon: <TikTokIcon /> },
  { name: 'Instagram', handle: '@mig.cs', url: 'https://www.instagram.com/mig.cs/', icon: <Instagram /> },
  { name: 'YouTube', handle: '@migcs', url: 'https://www.youtube.com/@migcs', icon: <Youtube /> },
  { name: 'Steam', handle: '/id/migcs', url: 'https://steamcommunity.com/id/migcs/', icon: <SteamIcon /> },
]

export default function MigSite() {
  const [page, setPage] = useState<Page>('home')
  const [menuOpen, setMenuOpen] = useState(false)
  const [privacyOpen, setPrivacyOpen] = useState(false)
  useEffect(() => {
    const readLocation = () => { const hash = window.location.hash.slice(1); setPage(navigation.some((item) => item.id === hash) ? hash as Page : 'home') }
    readLocation()
    window.addEventListener('hashchange', readLocation)
    return () => window.removeEventListener('hashchange', readLocation)
  }, [])
  const navigate = (nextPage: Page) => { setPage(nextPage); setMenuOpen(false); window.location.hash = nextPage; window.scrollTo({ top: 0, behavior: 'smooth' }) }
  return <div className="site-shell" data-page={page}>
    <a className="skip-link" href="#main-content">Saltar para o conteúdo</a>
    <header className="site-header container"><a href="#home" className="wordmark" aria-label="mig — Home" onClick={() => navigate('home')}><img src="/mig-logo.webp" alt="mig" width={480} height={366} /></a><button className="mobile-menu" onClick={() => setMenuOpen(!menuOpen)} aria-expanded={menuOpen} aria-controls="main-nav" aria-label={menuOpen ? 'Fechar menu' : 'Abrir menu'}>{menuOpen ? <X /> : <Menu />}</button><div className="sidebar-menu-label"><span className="status-dot" /> MENU</div><nav id="main-nav" className={menuOpen ? 'navigation open' : 'navigation'} aria-label="Menu principal">{navigation.map((item) => <a href={`#${item.id}`} key={item.id} className={page === item.id ? 'nav-link active' : 'nav-link'} aria-current={page === item.id ? 'page' : undefined} onClick={() => navigate(item.id)}><span>{item.label}</span><ArrowUpRight className="nav-arrow" size={13} /></a>)}</nav><div className="sidebar-bottom"><span className="small-tag">LINKS</span><div className="sidebar-socials">{socials.map((social) => <a href={social.url} key={social.name} target="_blank" rel="noopener noreferrer" aria-label={social.name}>{social.icon}</a>)}</div><a className="sidebar-signoff" href="mailto:emailmigcs@gmail.com">emailmigcs@gmail.com<ArrowUpRight size={13} /></a></div></header>
    <main className="container" id="main-content">{page === 'home' ? <Home /> : <FormPage page={page} onPrivacy={() => setPrivacyOpen(true)} />}</main>
    <footer className="site-footer container"><a href="#home" className="footer-logo" aria-label="mig — Home" onClick={() => navigate('home')}><img src="/mig-logo.webp" alt="mig" width={480} height={366} loading="lazy" /></a><div className="footer-right"><button onClick={() => setPrivacyOpen(true)}>Privacidade</button><span>© {new Date().getFullYear()} mig</span><span className="footer-made">GG. ATÉ AO PRÓXIMO.</span></div></footer>
    {privacyOpen ? <PrivacyDialog close={() => setPrivacyOpen(false)} /> : null}
  </div>
}

function Home() {
  const content = useSiteContent()
  return <>
    {content.showSocials !== 'false' ? <section className="social-section" aria-label="Redes sociais"><div className="social-grid">{socials.map((social) => <ExternalLink key={social.name} href={social.url} className="social-card"><span className="social-icon">{social.icon}</span><span className="social-info"><strong>{social.name}</strong><span>{social.handle}</span></span><ArrowUpRight className="social-arrow" size={19} /></ExternalLink>)}</div></section> : null}
    {content.showAbout !== 'false' ? <section className="about-card"><div className="about-label"><img src="/skin-selling-banner.png" alt="Jogador de CS2 com equipamento de visão noturna" /></div><div className="about-copy"><h2>{content.aboutTitle || 'FARTO DE JOGAR? FAZ DINHEIRO COM AS TUAS SKINS!'}</h2><p>{content.aboutDescription || 'Caso estejas aborrecido de jogar ou tenhas alguma urgência e necessites de vender as tuas skins, eu compro-as.'}</p><a className="about-cta" href="/#skins">VENDER SKINS <ArrowUpRight size={16} /></a></div><span className="about-corner" aria-hidden="true">↗</span></section> : null}
    {content.showAbout !== 'false' ? <section className="about-card" aria-labelledby="marketplace-heading"><div className="about-label"><img src="/skin-marketplace-banner.jpg" alt="Agente de CS2 a controlar skins e caixas com fios" loading="lazy" /></div><div className="about-copy"><h2 id="marketplace-heading">NÃO TE DEIXES ENGANAR, COMPRA SKINS BARATAS</h2><p>Sugestão de marketplace: se pretendes comprar skins aos melhores preços do mercado, recomendamos o Buff Market. O Buff163 está limitado a utilizadores asiáticos, por isso o mesmo fundador criou o Buff Market, a sua versão ocidental.</p><ExternalLink className="about-cta" href="https://buff.market/referral_draw?ref=U1090538120">VISITAR <ArrowUpRight size={16} /></ExternalLink></div><span className="about-corner" aria-hidden="true">↗</span></section> : null}
    {content.showVideos !== 'false' ? <Videos /> : null}
  </>
}

function Videos() {
  return <section className="videos-section" id="videos" aria-labelledby="videos-heading"><div className="videos-heading"><div><div className="eyebrow">TALVEZ GOSTES</div><h2 id="videos-heading">SUGESTÃO</h2></div><ExternalLink href="https://www.youtube.com/watch?v=v29zN2EHDEs" className="text-link">Abrir no YouTube <ArrowUpRight size={17} /></ExternalLink></div><div className="youtube-embed"><iframe src="https://www.youtube.com/embed/v29zN2EHDEs?autoplay=1&mute=1&rel=0&playsinline=1" title="Vídeo sugerido pelo mig" allow="autoplay; encrypted-media; picture-in-picture" allowFullScreen /></div></section>
}

function Modal({ children, close, title }: { children: ReactNode; close: () => void; title: string }) {
  useEffect(() => {
    const previousFocus = document.activeElement as HTMLElement | null
    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    const dialog = document.getElementById('site-dialog')
    dialog?.focus()
    const handleKey = (event: KeyboardEvent) => {
      if (event.key === 'Escape') close()
      if (event.key === 'Tab' && dialog) {
        const focusable = Array.from(dialog.querySelectorAll<HTMLElement>('button, a[href], iframe, [tabindex="0"]'))
        const first = focusable[0]; const last = focusable[focusable.length - 1]
        if (event.shiftKey && (document.activeElement === first || document.activeElement === dialog)) { event.preventDefault(); last?.focus() }
        else if (!event.shiftKey && document.activeElement === last) { event.preventDefault(); first?.focus() }
      }
    }
    document.addEventListener('keydown', handleKey)
    return () => { document.body.style.overflow = previousOverflow; document.removeEventListener('keydown', handleKey); previousFocus?.focus() }
  }, [close])
  return <div className="modal-backdrop" onClick={close}><section id="site-dialog" className="modal" role="dialog" aria-modal="true" aria-label={title} tabIndex={-1} onClick={(event) => event.stopPropagation()}><button className="modal-close" aria-label="Fechar" onClick={close}><X /></button>{children}</section></div>
}
function PrivacyDialog({ close }: { close: () => void }) {
  return <Modal close={close} title="Privacidade"><div className="privacy-content"><span className="eyebrow">OS TEUS DADOS</span><h2>Privacidade<span>.</span></h2><p>Os dados dos formulários são guardados no servidor de alojamento do site e usados pelo mig para avaliar candidaturas, responder a propostas de skins e tratar de parcerias. Não publiques palavras-passe, dados bancários ou chaves de carteiras nos formulários.</p><p>O nome da tua rede social permite verificar manualmente se segues o mig. O envio não garante participação num vídeo. A autorização para publicar detalhes do inventário é solicitada separadamente, se fores selecionado.</p><p>Para pedir acesso, correção ou eliminação dos teus dados, contacta <ExternalLink href="https://www.instagram.com/mig.cs/">@mig.cs no Instagram</ExternalLink>, identificando a tua submissão.</p><p>O site não usa cookies de publicidade próprios. Ao abrir redes sociais ou reproduzir um vídeo incorporado, aplicam-se também as políticas dessas plataformas.</p><button className="button primary" onClick={close}>Entendido <Check size={17} /></button></div></Modal>
}

type FormType = 'inventory' | 'skins' | 'partnership'
function FormShell({ type, children, onPrivacy }: { type: FormType; children: ReactNode; onPrivacy: () => void }) {
  const [state, setState] = useState<'idle' | 'sending' | 'success' | 'error'>('idle')
  const [error, setError] = useState('')
  const handleSubmit = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault(); const form = event.currentTarget; const data = Object.fromEntries(new FormData(form).entries()); setState('sending'); setError('')
    try { const response = await fetch('/api/submissions', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ type, ...data }) }); const result = await response.json() as { message?: string }; if (!response.ok) throw new Error(result.message || 'Não foi possível enviar. Tenta novamente.'); setState('success'); form.reset() }
    catch (failure) { setError(failure instanceof Error ? failure.message : 'Ocorreu um erro de ligação. Tenta novamente.'); setState('error') }
  }
  if (state === 'success') return <div className="form-card success-card" role="status"><span className="success-icon"><Check size={30} /></span><span className="eyebrow">RECEBIDO. GG!</span><h2>{type === 'inventory' ? 'Estás na lista.' : 'Proposta enviada.'}</h2><p>{type === 'inventory' ? 'A tua candidatura foi guardada. Se fores selecionado, o mig entra em contacto pela rede social que indicaste.' : 'A tua proposta foi guardada. O mig entra em contacto se houver interesse.'}</p><button className="button secondary" onClick={() => setState('idle')}>Enviar outro pedido <ArrowRight size={17} /></button></div>
  return <form className="form-card" onSubmit={handleSubmit}><div className="form-card-heading"><span>OS TEUS DADOS</span><span>* CAMPOS OBRIGATÓRIOS</span></div><fieldset disabled={state === 'sending'}>{children}<div className="honeypot" aria-hidden="true"><label>Não preencher<input name="website" tabIndex={-1} autoComplete="off" /></label></div><label className="consent-row"><input type="checkbox" name="privacyConsent" value="yes" required /><span>Autorizo o tratamento destes dados para responder a este pedido. <button type="button" onClick={onPrivacy}>Ler privacidade</button>.</span></label>{error ? <p className="form-error" role="alert">{error}</p> : null}<button className="button primary form-submit" type="submit">{state === 'sending' ? 'A enviar…' : type === 'inventory' ? 'Enviar o meu inventário' : 'Enviar proposta'}{state === 'sending' ? <span className="loading-indicator" /> : <ArrowUpRight size={18} />}</button><p className="form-safe"><ShieldCheck size={14} />Embora estes dados não sejam importantes, não deixam de estar protegidos, ao abrigo da Lei n.º 58/2019, de 08 de Agosto.</p></fieldset></form>
}
function InputField({ label, name, placeholder, type = 'text', required = true, hint, maxLength = 150 }: { label: string; name: string; placeholder: string; type?: string; required?: boolean; hint?: string; maxLength?: number }) {
  return <label className="field"><span>{label}{required ? <b> *</b> : <small> opcional</small>}</span><input name={name} type={type} placeholder={placeholder} required={required} maxLength={maxLength} autoComplete={name === 'name' ? 'name' : name === 'email' ? 'email' : 'off'} aria-describedby={hint ? `${name}-hint` : undefined} />{hint ? <small id={`${name}-hint`}>{hint}</small> : null}</label>
}
const formContent = {
  inventario: { type: 'inventory' as FormType, tag: 'O PRÓXIMO VÍDEO PODE SER TEU', title: 'Preenche o formulário,', accent: 'poderás ser o escolhido.', description: 'O teu inventário vale pouco? Muito? Não interessa, se queres fazer parte do canal e se queres ter o teu inventário analisado, participa.', steps: [{ title: 'Preenche o formulário', description: 'Preenche os dados e partilha o teu perfil Steam.' }, { title: 'Faz parte da comunidade', description: 'É obrigatório seguir @mig.cs no TikTok ou Instagram.' }, { title: 'Fica atento', description: 'Se fores selecionado, recebes uma mensagem na rede indicada.' }], note: 'Nunca é necessário enviar skins ou fornecer a tua palavra-passe para participar.' },
  skins: { type: 'skins' as FormType, tag: 'SABIAS QUE PODES VENDER AS TUAS SKINS, CAIXAS, CÁPSULAS POR DINHEIRO REAL?', title: 'Estás farto das tuas skins?', accent: 'Recebe dinheiro real por elas.', description: '', steps: [{ title: 'Preenche os teus dados', description: 'Para conseguir contactar-te, preenche corretamente os dados' }, { title: 'Oferta atualizada', description: 'A nossa oferta é calculada ao minuto e pode ser alterada a qualquer instante' }, { title: 'Escolhe o pagamento', description: 'Transferência direta ou cripto.' }, ], note: 'Aviso importante: o valor de mercado das skins apresentado não corresponde ao da Steam, nem ao de marketplaces de terceiros que inflacionam os preços para te prejudicar nas taxas.\n\nTodos os valores indicados pela nossa equipa são calculados diariamente, com base nos preços do BUFF163, já com a nossa margem deduzida.' },
  parcerias: { type: 'partnership' as FormType, tag: 'ÉS DONO DE UMA MARCA E/OU PROJETO E QUERES TRABALHAR COMIGO?', title: 'Vamos fazer acontecer.', accent: '', description: '', steps: [{ title: 'Conta-me a tua ideia', description: 'Partilha os objetivos, o formato e o que tens em mente.' }, { title: 'Conteúdo com intenção', description: 'Projetos que respeitam o jogo e a comunidade.' }, { title: 'CELERIDADE', description: 'Tentaremos responder à tua proposta o quanto antes' }], note: 'O melhor conteúdo nasce de uma boa ligação. Vamos criar algo que faça sentido para ambos.' },
}
function FormPage({ page, onPrivacy }: { page: Exclude<Page, 'home'>; onPrivacy: () => void }) {
  const content = formContent[page]
  return <div className="inner-page"><div className="page-heading"><div className="eyebrow"><span className="short-line" />{content.tag}</div><div className="page-title-row"><h1>{content.title}{content.accent ? <><br /><span>{content.accent}</span></> : null}</h1></div>{content.description ? <p>{content.description}</p> : null}</div><div className="form-layout"><FormShell key={page} type={content.type} onPrivacy={onPrivacy}>{page === 'inventario' ? <InventoryFields /> : page === 'skins' ? <SkinFields /> : <PartnershipFields />}</FormShell><aside className="form-aside"><span className="small-tag">COMO FUNCIONA</span><h2>{page === 'parcerias' ? 'Qual é o teu plano?' : <>O que tenho de fazer?</>}</h2><div className="steps">{content.steps.map((step, index) => <div className="step" key={step.title}><span>0{index + 1}</span><div><h3>{step.title}</h3><p>{step.description}</p></div></div>)}</div><div className="aside-note warning-note"><ShieldCheck size={20} /><p>{content.note}</p></div>{page !== 'parcerias' ? <ExternalLink href="https://steamcommunity.com/id/migcs/" className="text-link">A minha única Steam<ArrowUpRight size={16} /></ExternalLink> : null}</aside></div></div>
}
function InventoryFields() {
  return <><InputField label="Nome pessoal" name="name" placeholder="Como te chamas?" /><InputField label="Link do perfil Steam" name="steamUrl" placeholder="https://steamcommunity.com/id/o_teu_perfil" type="url" hint="Aceitamos /id/ ou /profiles/. Deixa o inventário público para o poder analisar." maxLength={250} /><div className="form-row"><label className="field"><span>Rede social <b>*</b></span><select name="platform" required defaultValue=""><option value="" disabled>Seleciona a rede</option><option value="tiktok">TikTok</option><option value="instagram">Instagram</option></select></label><InputField label="O teu @username" name="socialHandle" placeholder="@o_teu_nome" hint="Para te contactar e confirmar que me segues." maxLength={80} /></div><label className="consent-row follow-consent"><input type="checkbox" name="followsCreator" value="yes" required /><span>Confirmo que sigo <ExternalLink href="https://www.tiktok.com/@mig.cs">@mig.cs</ExternalLink> no TikTok ou Instagram. A verificação é manual.</span></label></>
}
type Wear = 'factory-new' | 'minimal-wear' | 'field-tested' | 'well-worn' | 'battle-scarred'
const wearOptions: { value: Wear; label: string; short: string }[] = [{ value: 'factory-new', label: 'Factory New', short: 'FN' }, { value: 'minimal-wear', label: 'Minimal Wear', short: 'MW' }, { value: 'field-tested', label: 'Field-Tested', short: 'FT' }, { value: 'well-worn', label: 'Well-Worn', short: 'WW' }, { value: 'battle-scarred', label: 'Battle-Scarred', short: 'BS' }]
type SkinQuote = { name: string; image: string | null; buffEur: number; offerEur: number; sourceUrl: string }
type SkinItem = { id: number; name: string; wear: Wear | null; status: 'idle' | 'loading' | 'ready' | 'error'; quote?: SkinQuote; message?: string }
const euro = new Intl.NumberFormat('pt-PT', { style: 'currency', currency: 'EUR' })
function SkinFields() {
  const [items, setItems] = useState<SkinItem[]>([])
  const [draft, setDraft] = useState('')
  const nextId = useRef(1)
  const validator = useRef<HTMLInputElement>(null)
  const complete = items.length > 0 && items.every((item) => item.wear)
  useEffect(() => { validator.current?.setCustomValidity(complete ? '' : items.length ? 'Escolhe o estado de cada skin.' : 'Adiciona pelo menos uma skin.') }, [complete, items.length])
  const update = (id: number, changes: Partial<SkinItem>) => setItems((current) => current.map((item) => item.id === id ? { ...item, ...changes } : item))
  const addSkin = () => {
    const name = draft.trim()
    if (name.length < 3 || items.length >= 20) return
    setItems((current) => [...current, { id: nextId.current++, name, wear: null, status: 'idle' }]); setDraft('')
  }
  const chooseWear = async (item: SkinItem, wear: Wear) => {
    update(item.id, { wear, status: 'loading', quote: undefined, message: undefined })
    try {
      const response = await fetch(`/api/skin-price?${new URLSearchParams({ name: item.name, wear })}`)
      const result = await response.json() as SkinQuote & { message?: string }
      setItems((current) => current.map((entry) => entry.id !== item.id || entry.wear !== wear ? entry : response.ok ? { ...entry, status: 'ready', quote: result } : { ...entry, status: 'error', message: result.message || 'Não foi possível obter o preço.' }))
    } catch { setItems((current) => current.map((entry) => entry.id === item.id && entry.wear === wear ? { ...entry, status: 'error', message: 'Erro de ligação ao obter o preço. Tenta novamente.' } : entry)) }
  }
  const total = items.reduce((sum, item) => sum + (item.quote?.offerEur ?? 0), 0)
  return <><div className="form-row"><InputField label="Nome pessoal" name="name" placeholder="O teu nome" /><InputField label="TikTok ou Instagram" name="socialHandle" placeholder="@o_teu_nome" hint="Indica a rede e o username para te contactar." maxLength={80} /></div><InputField label="Link do perfil Steam" name="steamUrl" placeholder="https://steamcommunity.com/id/o_teu_perfil" type="url" maxLength={250} />
    <div className="skin-builder"><label className="field-label" htmlFor="skin-draft">Que skins queres vender? <b>*</b></label><div className="skin-add"><input id="skin-draft" value={draft} onChange={(event) => setDraft(event.target.value)} onKeyDown={(event) => { if (event.key === 'Enter') { event.preventDefault(); addSkin() } }} placeholder="Ex.: AK-47 | Redline ou StatTrak™ AWP | Asiimov" maxLength={120} aria-describedby="skin-draft-hint" /><button type="button" className="button secondary" onClick={addSkin} disabled={draft.trim().length < 3 || items.length >= 20}><Plus size={16} />Adicionar</button></div><small id="skin-draft-hint" className="skin-hint">Escreve o nome exato da skin, sem o estado. Adiciona uma de cada vez (até 20).</small>
      <input ref={validator} className="skin-validator" value={complete ? 'ok' : ''} onChange={() => undefined} required tabIndex={-1} aria-hidden="true" />
      <input type="hidden" name="items" value={JSON.stringify(items.filter((item) => item.wear).map((item) => ({ name: item.name, wear: item.wear })))} />
      {items.length ? <ul className="skin-list">{items.map((item) => <li className="skin-item" key={item.id}>
        <div className="skin-frame">{item.quote?.image ? <img src={item.quote.image} alt="" loading="lazy" /> : <span className="skin-frame-empty" aria-hidden="true"><Crosshair size={26} /></span>}<strong>{item.quote?.name || item.name}</strong></div>
        <div className="skin-detail"><div className="skin-detail-top"><span className="field-label" id={`wear-${item.id}`}>Estado <b>*</b></span><button type="button" className="skin-remove" onClick={() => setItems((current) => current.filter((entry) => entry.id !== item.id))} aria-label={`Remover ${item.name}`}><Trash2 size={15} /></button></div>
          <div className="wear-bar" role="radiogroup" aria-labelledby={`wear-${item.id}`}>{wearOptions.map((option) => <button type="button" role="radio" aria-checked={item.wear === option.value} key={option.value} className={item.wear === option.value ? 'active' : ''} onClick={() => chooseWear(item, option.value)} title={option.label}><b>{option.short}</b><span>{option.label}</span></button>)}</div>
          <div className="skin-quote" aria-live="polite">{item.status === 'idle' ? <span className="muted">Escolhe o estado para ver a oferta.</span> : item.status === 'loading' ? <span className="muted"><LoaderCircle size={14} className="spin" />A procurar no Buff163…</span> : item.status === 'error' ? <span className="quote-error">{item.message}</span> : item.quote ? <><span>Buff163 <strong>{euro.format(item.quote.buffEur)}</strong></span><span className="quote-offer">Oferta <strong>{euro.format(item.quote.offerEur)}</strong></span><ExternalLink href={item.quote.sourceUrl} className="quote-source">Ver preço<ArrowUpRight size={12} /></ExternalLink></> : null}</div>
        </div></li>)}</ul> : null}
      {total > 0 ? <div className="skin-total"><span>Oferta total estimada</span><strong>{euro.format(total)}</strong></div> : null}
    </div>
    <label className="field"><span>Detalhes e observações <small>opcional</small></span><textarea name="notes" placeholder="Float raro, pattern especial, stickers… Tudo o que possa valorizar as tuas skins." rows={3} maxLength={3000} /></label><div className="payment-field"><span className="field-label">Como preferes receber? <b>*</b></span><div className="payment-options">{[{ value: 'transfer', name: 'Transferência direta', mark: '€' }, { value: 'crypto', name: 'Cripto', mark: '₿' }].map((payment) => <label key={payment.value}><input name="payment" type="radio" value={payment.value} required /><span className="payment-mark">{payment.mark}</span><span>{payment.name}</span></label>)}</div></div></>
}
function PartnershipFields() {
  return <><InputField label="Nome / marca" name="name" placeholder="Como se chama a tua marca?" /><InputField label="Email de contacto" name="email" placeholder="ola@atuamarca.pt" type="email" maxLength={254} /><InputField label="Site ou rede social" name="brandUrl" placeholder="https://…" type="url" required={false} maxLength={300} /><label className="field"><span>A tua proposta <b>*</b></span><textarea name="message" placeholder="Conta-me a tua ideia, os objetivos da campanha e o que tens em mente." rows={6} required maxLength={5000} /></label></>
}
