import { drizzle } from 'drizzle-orm/node-postgres'
import { Pool } from 'pg'
import * as schema from './schema.js'

let pool: Pool | null = null

export function getPool() {
  if (!pool) {
    if (!process.env.DATABASE_URL) throw new Error('DATABASE_URL em falta')
    pool = new Pool({ connectionString: process.env.DATABASE_URL, max: 5 })
  }
  return pool
}

export function getDatabase() {
  return drizzle({ client: getPool(), schema })
}
