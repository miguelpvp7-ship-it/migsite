import { boolean, jsonb, pgTable, serial, text, timestamp } from 'drizzle-orm/pg-core'
import type { SkinOfferItem } from '../server/skin-pricing.js'

export const inventoryRequests = pgTable('inventory_requests', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  steamUrl: text('steam_url').notNull(),
  platform: text('platform').notNull(),
  socialHandle: text('social_handle').notNull(),
  followsCreator: boolean('follows_creator').notNull(),
  privacyConsent: boolean('privacy_consent').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})

export const skinOffers = pgTable('skin_offers', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  steamUrl: text('steam_url').notNull(),
  socialHandle: text('social_handle').notNull(),
  skins: text('skins').notNull(),
  wear: text('wear').notNull(),
  notes: text('notes').notNull(),
  payment: text('payment').notNull(),
  items: jsonb('items').$type<SkinOfferItem[]>().notNull().default([]),
  privacyConsent: boolean('privacy_consent').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})

export const partnershipRequests = pgTable('partnership_requests', {
  id: serial('id').primaryKey(),
  name: text('name').notNull(),
  email: text('email').notNull(),
  brandUrl: text('brand_url').notNull(),
  message: text('message').notNull(),
  privacyConsent: boolean('privacy_consent').notNull(),
  createdAt: timestamp('created_at', { withTimezone: true }).notNull().defaultNow(),
})

export const integrations = pgTable('integrations', {
  id: text('id').primaryKey(),
  encryptedAccessToken: text('encrypted_access_token').notNull(),
  encryptedRefreshToken: text('encrypted_refresh_token').notNull(),
  expiresAt: timestamp('expires_at', { withTimezone: true }).notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
})

export const siteContent = pgTable('site_content', {
  key: text('key').primaryKey(),
  value: text('value').notNull(),
  updatedAt: timestamp('updated_at', { withTimezone: true }).notNull().defaultNow(),
})
