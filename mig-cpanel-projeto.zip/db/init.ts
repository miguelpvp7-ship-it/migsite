// Cria as tabelas na primeira vez que o servidor arranca (é seguro correr várias vezes).
export const initSql = `
CREATE TABLE IF NOT EXISTS "integrations" (
  "id" text PRIMARY KEY,
  "encrypted_access_token" text NOT NULL,
  "encrypted_refresh_token" text NOT NULL,
  "expires_at" timestamp with time zone NOT NULL,
  "updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
CREATE TABLE IF NOT EXISTS "inventory_requests" (
  "id" serial PRIMARY KEY,
  "name" text NOT NULL,
  "steam_url" text NOT NULL,
  "platform" text NOT NULL,
  "social_handle" text NOT NULL,
  "follows_creator" boolean NOT NULL,
  "privacy_consent" boolean NOT NULL,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL
);
CREATE TABLE IF NOT EXISTS "partnership_requests" (
  "id" serial PRIMARY KEY,
  "name" text NOT NULL,
  "email" text NOT NULL,
  "brand_url" text NOT NULL,
  "message" text NOT NULL,
  "privacy_consent" boolean NOT NULL,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL
);
CREATE TABLE IF NOT EXISTS "skin_offers" (
  "id" serial PRIMARY KEY,
  "name" text NOT NULL,
  "steam_url" text NOT NULL,
  "social_handle" text NOT NULL,
  "skins" text NOT NULL,
  "wear" text NOT NULL,
  "notes" text NOT NULL,
  "payment" text NOT NULL,
  "items" jsonb DEFAULT '[]' NOT NULL,
  "privacy_consent" boolean NOT NULL,
  "created_at" timestamp with time zone DEFAULT now() NOT NULL
);
CREATE TABLE IF NOT EXISTS "site_content" (
  "key" text PRIMARY KEY,
  "value" text NOT NULL,
  "updated_at" timestamp with time zone DEFAULT now() NOT NULL
);
ALTER TABLE "skin_offers" ADD COLUMN IF NOT EXISTS "items" jsonb DEFAULT '[]' NOT NULL;
`
